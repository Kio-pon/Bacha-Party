#include "list.h"
using namespace std;

void list::print(){
    for(int i = 0; i < count; i++){
        cout << book[i] << " ";
    }
    cout << endl;
}

void list::push(const string& word){
    string* new_book = new string[count + 1];
    for(int i = 0; i < count; i++){
        new_book[i] = book[i];
    }
    new_book[count] = word;

    delete[] book;
    book = new_book;
    count++;
}

void list::pop(){
    /*
        pop is never called on an empty list.
        If this assumption is abandoned then
            if (count == 0) return;
    */
    string* new_book = new string[count - 1];
    for(int i = 0; i < count - 1; i++){
        new_book[i] = book[i];
    }

    delete[] book;
    book = new_book;
    count--;
}

void list::reverse(){
    string* new_book = new string[count];
    for(int i = count - 1, j = 0; 
        i >= 0; 
        i--, j++){
            new_book[j] = book[i];
    }

    delete[] book;
    book = new_book;

    // for (unsigned int i = 0; i < count / 2; i++) {
    //     std::swap(book[i], book[count - 1 - i]);
    // }
}

list list::select(int i, int j){
    list new_list;
    /*
        We assume i <= j and both of them are not out of bounds
        If that were not the case then following would be the code:
            if(j < i) return new_list;
            if(i < 0 || j > count - 1) return new_list;
    */
    
    for(int x = i; x <= j; x++){
        new_list.push(book[x]);
    }

    // for(int k = 0; k < j - i + 1; k++){
    //      new_list.push(book[i + k]);
    // }
    

    return new_list;
}

list::~list(){
    delete[] book;
}
