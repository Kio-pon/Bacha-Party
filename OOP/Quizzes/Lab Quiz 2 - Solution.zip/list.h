#ifndef LIST_H
#define LIST_H

#include <iostream>

struct list{
    // data
    unsigned int count = 0;
    std::string* book = nullptr;

    // functions
    void print();
    void push(const std::string&);
    void pop();
    void reverse();
    list select(int, int); //assume j -> ending index, i -> starting index (both inclusive)

    // destructor [IGNORE THIS PART]
    ~list();
};

#endif