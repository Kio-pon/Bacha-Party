#include "list.h"
using namespace std;

int main(){
    // Test 1: Push and display
    cout << "TEST - 1 - PUSH" << endl << "EXPECTED: apple banana cherry peach mango lemon" << endl;
    list L;
    L.push("apple");
    L.push("banana");
    L.push("cherry");
    L.push("peach");
    L.push("mango");
    L.push("lemon");
    L.print();
    cout << endl;

    // Test 2: Pop
    cout << "TEST - 2 - POP" << endl << "EXPECTED: apple banana cherry peach mango" << endl;
    L.pop();
    L.print();
    cout << endl;

    // Test 3: Reverse
    cout << "TEST - 3 - REVERSE" << endl << "EXPECTED: mango peach cherry banana apple" << endl;
    L.reverse();
    L.print();
    cout << endl;

    // Test 4: Select sublist
    cout << "TEST - 4 - SELECT" << endl << "EXPECTED: cherry banana" << endl;
    list sub = L.select(2, 3);
    sub.print();

    return 0;

}