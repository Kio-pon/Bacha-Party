#include <iostream>
#include "network.h"
using namespace std;

int main(){
    Person A;
    cout << "Total People: " << A.totalPeople() << endl;
    Person B(A);
    cout << "Total People: " << A.totalPeople() << endl;
    Person C("Tauqeer", nullptr);
    cout << "Total People: " << A.totalPeople() << endl;
    Person D = C;
    cout << "Total People: " << A.totalPeople() << endl;
    A.addFriend(&A);
    A.addFriend(&B);
    A.addFriend(&C);
    A.addFriend(&D);
    A.showFriends();
}