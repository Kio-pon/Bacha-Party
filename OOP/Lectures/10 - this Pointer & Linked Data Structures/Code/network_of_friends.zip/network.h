#ifndef NETWORK_H 
#define NETWORK_H

#include <iostream>
using namespace std;

class Person{
    public:
        // rule of 3
        Person();
        Person(const string&, Person**);
        Person(const Person&);                                              // Copy Constructor
        Person& operator=(const Person&);                                   // Copy Assignment Operator 
        ~Person();                                                          // Destructor
        // methods
        void addFriend(Person*);
        void showFriends() const;
        int totalPeople() const {return CountPeople;}
    private:
        static int CountPeople;
        string name;
        Person** connections;
        int CountConnections;       
};

#endif