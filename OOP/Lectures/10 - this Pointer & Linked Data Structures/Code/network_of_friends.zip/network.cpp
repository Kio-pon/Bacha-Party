#include <iostream>
#include "network.h"
using namespace std;

// static data members
int Person::CountPeople = 0;

// constructors 
Person::Person() : name("Unnamed"), connections(nullptr), CountConnections(0) {CountPeople++;}

Person::Person(
    const string& n,  
    Person** con) : name(n), connections(con), CountConnections(0)
    {CountPeople++;}

Person::Person(
    const Person& another) : name(another.name),
        connections(new Person*[another.CountConnections]),
        CountConnections(another.CountConnections){
            copy(another.connections, another.connections + CountConnections, connections);
            CountPeople++;
        }

Person& Person::operator=(const Person& another){
    name = another.name;
    CountConnections = another.CountConnections;
    copy(another.connections, another.connections + CountConnections, connections);
    CountPeople++;
    return *this;
}

// destructor
Person::~Person(){
    delete[] connections;
}

// methods
void Person::addFriend(Person* friendo){
    Person** temp = new Person*[CountConnections + 1];
    copy(connections, connections + CountConnections, temp);
    temp[CountConnections] = friendo;
    delete[] connections;
    CountConnections++;
    connections = temp;
}

void Person::showFriends() const{
    for(int i = 0; i < CountConnections; i++){
        cout << connections[i]->name << " ";
    }
    cout << endl;
}