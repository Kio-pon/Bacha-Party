#include <iostream>
#include <cstring>   

// for strlen

using namespace std;

// Function to reverse a C-style string into another string
void reverseString(const char input[], char output[]) {
    int len = strlen(input);

    for (int i = 0; i < len; i++) {
        output[i] = input[len - i - 1];
    }

    // Add null terminator
    output[len] = '\0';
}

int main() {
    char str[200];
    char rev[200];

    cout << "Enter a string (no spaces): ";
    cin >> str;

    reverseString(str, rev);

    cout << "Original string: " << str << endl;
    cout << "Reversed string: " << rev << endl;

    return 0;
}
