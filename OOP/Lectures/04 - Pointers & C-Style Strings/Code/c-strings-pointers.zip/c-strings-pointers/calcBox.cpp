#include <iostream>
using namespace std;

// Function to calculate surface area and volume of a box
void calculateBox(float length, float width, float height, float* surfaceArea, float* volume) {
    // Surface Area = 2(lw + lh + wh)
    *surfaceArea = 2 * (length * width + length * height + width * height);

    // Volume = l * w * h
    *volume = length * width * height;
}

int main() {
    float length, width, height;
    float surfaceArea, volume;

    cout << "Enter length: ";
    cin >> length;
    cout << "Enter width: ";
    cin >> width;
    cout << "Enter height: ";
    cin >> height;

    // Call function with addresses of surfaceArea and volume
    calculateBox(length, width, height, &surfaceArea, &volume);

    cout << "Surface Area = " << surfaceArea << " square units" << endl;
    cout << "Volume = " << volume << " cubic units" << endl;

    return 0;
}
