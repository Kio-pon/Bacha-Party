#include <iostream>

using namespace std;

int main() {
    char str[200];

    cout << "Enter a string (no spaces): ";
    cin.get(str, 80);
    cout << "You entered: " << str << endl;
    return 0;
}