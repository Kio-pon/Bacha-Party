#include <iostream>



int main() {
    const int MAX = 8;
    char str[MAX];

    std::cout << "Enter your string (8 char max): ";
    std::cin >> str;
    //std::cin.get(str, MAX);

    std::cout << "Your string is: " << str << std::endl;
    return 0;
}