#include <iostream>

using namespace std;

int main() {
    int a = 35;
    int *b = &a; // b is an alias to a

    cout << "a = " << a << endl;
    cout << "b = " << *b << endl;

    *b = *b + 1;
    cout << "Now, after incrementing b " << endl;

    cout << "a = " << a << endl;
    cout << "b = " << *b << endl;

    return 0;
}