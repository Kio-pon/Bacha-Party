#include <iostream>

using namespace std;

void transfer(int*, int*);

int main() {
    int src = 4, dest = 0;
    cout << "Before transfer " << endl;
    cout << "src = " << src << ", dest = " << dest << endl;
    transfer(&src, &dest);
    cout << "After transfer " << endl;
    cout << "src = " << src << ", dest = " << dest << endl;
    return 0;
}

void transfer(int *src, int *dest) {
    *dest = *dest + *src;
    *src = 0;
    return;
}