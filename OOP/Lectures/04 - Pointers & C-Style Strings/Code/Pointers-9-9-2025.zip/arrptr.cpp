#include <iostream>

using namespace std;

int main() {
    int a[] = {5, 3, 4, 2, 1};
    for(int ix = 0; ix < 5; ix++)
        cout << "a[" << ix << "] = " << *(a + ix) << endl;
    return 0;
}