#include <iostream>

using namespace std;

void transfer(int&, int&);

int main() {
    int src = 4, dest = 0;
    cout << "Before transfer " << endl;
    cout << "src = " << src << ", dest = " << dest << endl;
    transfer(src, dest);
    cout << "After transfer " << endl;
    cout << "src = " << src << ", dest = " << dest << endl;
    return 0;
}

void transfer(int& src, int& dest) {
    dest = dest + src;
    src = 0;
    return;
}

//Very first application of pointers

//Write a program that SWAPS the values of 2 variables using pointers.
//Just paste it in the chat.
