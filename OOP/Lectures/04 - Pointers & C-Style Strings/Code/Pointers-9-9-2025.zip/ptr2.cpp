#include <iostream>

using namespace std;

int main() {
    int x = 35, y;
    int* ptr = &x; //ptr is a pointer to an integer
    y = *ptr;

    cout << "x = " << x << endl;
    cout << "Address of x = " << ptr << endl;
    cout << "The value stored at the above address is " << y << endl;

    return 0;
}