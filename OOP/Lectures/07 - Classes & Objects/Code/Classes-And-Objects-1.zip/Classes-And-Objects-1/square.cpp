#include <iostream>

using namespace std;

class square {
    private:
        float side;
    public:
        float get_side() {          return side;        }
        void set_side(float s) {    side = s;           }
        float calc_area() {         return side * side; }
};

int main() {
    square s1, s2, s3;
    s1.set_side(5.0f);
    s2.set_side(1.75f);
    s3.set_side(0);

    cout << "Square 1 has side " << s1.get_side() << ", area = " << s1.calc_area() << " square units " << endl;
    cout << "Square 2 has side " << s2.get_side() << ", area = " << s2.calc_area() << " square units " << endl;
    cout << "Square 3 has side " << s3.get_side() << ", area = " << s3.calc_area() << " square units " << endl;
    return 0;
}