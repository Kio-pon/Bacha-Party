#include <iostream>

using namespace std;

class square2 {
    private:
        float side;
        void decrease_by_point9() {      side = 0.9*side; }
    public:
        float pi = 3.1416f;
        float get_side() {          return side;        }
        void set_side(float s) {    side = s;           }
        float calc_area() {         decrease_by_point9();  return side * side; }
};

int main() {
    square2 s1, s2, s3;
    s1.set_side(5.0f);
    s2.set_side(1.75f);
    s3.set_side(0);

    cout << "Square 1 has side " << s1.get_side() << ", area = " << s1.calc_area() << " square units " << endl;
    cout << "Square 2 has side " << s2.get_side() << ", area = " << s2.calc_area() << " square units " << endl;
    cout << "Square 3 has side " << s3.get_side() << ", area = " << s3.calc_area() << " square units " << endl;
    
    cout << "Square2 1 has pi = " << s1.pi << endl;
    cout << "Reduce square size " << endl;
    //s1.decrease_by_point9();
    return 0;
}