#include <iostream>
using namespace std;
////////////////////////////////////////////////////////////////
class smallobj 
//define a class
{
    private:
        int counter = 0;
        void incCounter() {
            counter = counter + 1;
        }
    public:
        int somedata; //class data
        
        void setdata(int d) //member function to set data
        { somedata = d; somedata = somedata + 1; }

        void showdata() //member function to display data
        { cout << "Data is " << somedata << endl; 
            incCounter();
        }

        void calculateTax() {
            int tax = counter * 10;
            cout << "Tax is " << tax << endl;
        }
};
////////////////////////////////////////////////////////////////
int main()
{
    int a = 8;
    smallobj s1, s2, s3; //define two objects of class smallobj
    s1.setdata(1066); //call member function to set data
    s2.setdata(1776);
    s3.setdata(a);
    s1.showdata(); //call member function to display data
    s1.showdata(); //call member function to display data
    s1.showdata(); //call member function to display data
    s1.showdata(); //call member function to display data
    //s1.counter = -20;
    s2.showdata();
    s1.calculateTax();
    return 0;
}