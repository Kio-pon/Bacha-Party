#include <iostream>

using namespace std;

class circle {
    private:
        double radius;
    public:
        void set_radius(double r) {
            radius = r;
        }

        double calc_circumference() {
            return 2 * 3.1416 * radius;
        }

        double calc_area() {
            return 3.1416 * radius * radius;
        }

        void print_circle() {
            cout << "Circle: Radius = " << radius << ", Circumference = " << calc_circumference() << ", Area = " << calc_area() << endl;        
        }
};

int main(void) {
    circle c1, c2;
    c1.set_radius(4.0);
    c2.set_radius(3.5);

    c1.print_circle();
    c2.print_circle();
}