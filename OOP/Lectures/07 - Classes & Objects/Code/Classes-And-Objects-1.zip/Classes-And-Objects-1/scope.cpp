#include <iostream>

using namespace std;


int main(void) {    
    int number = 20;
    int val = 0;
    while(val <= 20) {
        val = val + 2;
        int tries = 0;
        tries = tries + 1;
    }
    cout << tries;
}