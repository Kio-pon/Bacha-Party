#include <iostream>

using namespace std;

class circle {
    private:
        double radius, area, circum;
    public:
        void set_radius(double r) {
            radius = r;
        }

        void calc_circumference() {
            circum = 2 * 3.1416 * radius;
        }

        void calc_area() {
            area = 3.1416 * radius * radius;
        }

        void print_circle() {
            calc_circumference();
            calc_area();
            cout << "Circle: Radius = " << radius << ", Circumference = " << circum << ", Area = " << area << endl;        
        }
};

int main(void) {
    circle c1, c2;
    c1.set_radius(4.0);
    c2.set_radius(3.5);

    c1.print_circle();
    c2.print_circle();
}