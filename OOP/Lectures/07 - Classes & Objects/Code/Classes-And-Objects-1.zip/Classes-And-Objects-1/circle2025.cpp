#include <iostream>

class Circle {
    private:
        int radius;
        const float PI;
    public:
        Circle() : radius(0), PI(3.1416f) 
        {   std::cout << "I am default constructor\n"; }
        Circle(int r) : PI(3.1416f) {
            radius = r;
            std::cout << "I am argument constructor\n"; 
        }
        void print_circle() {
            std::cout << "circle with area = "<< (PI*radius*radius) <<" sq units" << std::endl;
        }
};

int main() {
    Circle c1, c2(5);
    c1.print_circle();
    c2.print_circle();
}


