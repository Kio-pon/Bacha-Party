#include <iostream>
#include <ctime>

using namespace std;

class Student {
    private:
        string name;
        int id;
    public:
        Student(string n, int i) : name(n), id(i) {}
        string get_name() {
            return name;
        }
        int get_id() {
            return id;
        }
        virtual string get_project_type() = 0;
        //no implementation
        //If a class has a pure virtual function, then it is abstract
        //and objects cannot be created out of it.
};

class ScienceStudent : public Student {
    public:
        ScienceStudent(string n, int s) : Student(n, s) {}
        string get_project_type() {
            return " Programming";
        }
        string get_PL() {
            return "C++";
        }
};

class ArtsStudent : public Student {
    public:
        ArtsStudent(string n, int s) : Student(n, s) {}
        string get_project_type() {
            return " Artistic";
        }
        string get_favorite_poet() {
            return "Shakespeare";
        }
};

int main() {
    //Student s("Aziz", 5019);
    ScienceStudent t("Ahmed", 1914);
    ArtsStudent u("Zohra", 4569);

    //cout << s.get_name() << " " << s.get_id() << " " << s.get_project_type() << endl;
    cout << t.get_name() << " " << t.get_id() << " " << t.get_project_type() << endl;
    cout << u.get_name() << " " << u.get_id() << " " << u.get_project_type() << endl;
    
    Student* students[10];
    srand(time(0));
    int random;
    for(int i = 0; i < 10; i++) {
        random = rand() % 101;
        if(random % 2 == 0) {
            students[i] = new ScienceStudent("Apple", random);
            ArtsStudent* a = (ArtsStudent *) students[i];
            cout << a->get_favorite_poet();
        }
        else {
            students[i] = new ArtsStudent("Cherry", random);
            cout <<  ((ArtsStudent *) students[i])->get_favorite_poet();
        }
        cout << students[i]->get_name() << " " << students[i]->get_id() 
            << " " << students[i]->get_project_type() << endl;
    }
    return 0;
}