#include <iostream>

#define ROWS 3
#define COLS 4

using namespace std;

void print(int matrix[][COLS]) {
    cout << "The 2-D array is " << endl;
    for(int i = 0; i < ROWS; i++) {
        for(int j = 0; j < COLS; j++) {
            cout << matrix[i][j] << "\t";
        }
        cout << "\n";
    }
}

int main() {
    int data[ROWS][COLS];

    for(int i = 0; i < ROWS; i++) {
        for(int j = 0; j < COLS; j++) {
            cout << "Enter value at (" << i << ", " << j << "): ";
            cin >> data[i][j]; 
        }
    }
    print(data);
    return 0;
}