#include <iostream>

using namespace std;

void print_array(int a[], int size) {
    for(int jx = 0; jx < size; jx++) {
        cout << a[jx] << "\t";
    }
    cout << endl;
}

void increment(int a[], int size) {
    for(int kx = 0; kx < 4; kx++) {
        a[kx] = a[kx] + 1;
    }
}

int main(void) {
    int a[4];
    int val;

    //read size
    //a[size];

    for(int ix = 0; ix < 4; ix++) {
        cout << "Enter element " << ix << ": ";
        cin >> val;
        a[ix] = val;
    }

    print_array(a, 4);

    increment(a, 4);
    
    print_array(a, 4);

    return 0;
}