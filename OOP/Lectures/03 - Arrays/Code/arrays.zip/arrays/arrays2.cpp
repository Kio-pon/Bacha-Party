#include <iostream>

//#define SIZE 10
using namespace std;

int main() {
    int a[] = {1, 2, 3, 4};
    int b[4];

    for(int i = 0; i < 4; i++) {
        b[i] = a[i];
    }

    for(int i = 0; i < 4; i++) {
        cout << b[i] << " ";
    }

    return 0;

}