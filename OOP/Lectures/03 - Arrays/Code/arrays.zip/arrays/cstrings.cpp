#include <iostream>

#define MAX 10

using namespace std;

int main() {
    char str[MAX] = "COMPUTER";

    for(int i = 0; str[i] != '\0'; i++)
        cout << str[i] << " ";
    cout << "\n";
}