#include <iostream>

using namespace std;

bool is_prime(int val) {
    for(int div = 2; div < val; div++) {
        if(val % div == 0)
            return false;
    }
    return true;
}

int main() {
    int val;
    cout << "Enter an integer: ";
    cin >> val;

    for(int a = 2; a <= val; a++) {
        if(is_prime(a))
            cout << a << " ";
    }
    cout << "\n";
    return 0;
}