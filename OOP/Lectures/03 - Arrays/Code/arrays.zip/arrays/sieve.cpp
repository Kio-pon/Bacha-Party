#include <iostream>

#define SIZE 50

using namespace std;

int main() {
    int a[49];
    for(int i = 0; i < 49; i++) 
        a[i] = i+2;

    for(int j = 2; j <= 7; j++) {
        for(int i = 0; i < 49; i++) {
            if(a[i] != j && a[i] % j == 0)
                a[i] = -1;
        }
    }

    for(int i = 0; i < 49; i++)
        //if(a[i] > 0)
            cout << a[i] << " ";
    return 0;
}