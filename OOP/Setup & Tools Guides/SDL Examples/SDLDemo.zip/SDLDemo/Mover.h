void moveUp();
void moveRight();
void moveDown();
void update();

int X=30, Y=430;
// X, Y indicate the current position of top-left corner of Mario
// moveUp decreases the Y value by 1 
// moveDown increases the Y value by 1
// moveRight increases the X value by 1
// As you call moveUp, moveRight or moveDown function the X, Y values are updated accordingly
// the Game ends when X=650, Y=430

void UpdateMario(){
    for (int i=0;i<500;i++)
        moveRight();
}