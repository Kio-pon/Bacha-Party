#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <iostream>
#include "Mover.h"




/*This source code copyrighted by Lazy Foo' Productions (2004-2015)
and may not be redistributed without written permission.*/

//Using SDL, SDL_image, standard IO, and strings
//#include <SDL.h>
//#include <SDL_image.h>
//#include <stdio.h>
#include <string>

//Screen dimension constants
const int SCREEN_WIDTH = 800;
const int SCREEN_HEIGHT = 600;



//Starts up SDL and creates window
bool init();

//Loads media
bool loadMedia();

//Frees media and shuts down SDL
void close();

//Loads individual image as texture
SDL_Texture* loadTexture( std::string path );

//The window we'll be rendering to
SDL_Window* gWindow = NULL;

//The window renderer
SDL_Renderer* gRenderer = NULL;

//Current displayed texture
SDL_Texture* gTexture = NULL;
//global reference to png image sheets
SDL_Texture* bg = NULL;
SDL_Texture* mario=NULL;

SDL_Rect srcRect, marioSrc;
SDL_Rect mover, marioMover;

void update(){
	if (X>=650) return;
	SDL_RenderClear( gRenderer );
	SDL_RenderCopy( gRenderer, bg, &srcRect, &mover );
	SDL_RenderCopy( gRenderer, mario, &marioSrc, &marioMover );
	SDL_RenderPresent( gRenderer );
	SDL_Delay(5);	
}

void moveUp(){
	if (marioMover.y>=10){
		marioMover.y-=1;
		Y=marioMover.y;
	}
	update();
}

void moveDown(){
	if (marioMover.y<=430) {
		marioMover.y+=1;
		Y=marioMover.y;
	}
	update();
}

void moveRight(){
	if (marioMover.x<700) {
		marioMover.x+=1;
		X=marioMover.x;
	}
	update();
}

bool init()
{
	//Initialization flag
	bool success = true;

	//Initialize SDL
	if( SDL_Init( SDL_INIT_VIDEO ) < 0 )
	{
		printf( "SDL could not initialize! SDL Error: %s\n", SDL_GetError() );
		success = false;
	}
	else
	{
		//Set texture filtering to linear
		if( !SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY, "1" ) )
		{
			printf( "Warning: Linear texture filtering not enabled!" );
		}

		//Create window
		gWindow = SDL_CreateWindow( "SDL Tutorial", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN );
		if( gWindow == NULL )
		{
			printf( "Window could not be created! SDL Error: %s\n", SDL_GetError() );
			success = false;
		}
		else
		{
			//Create renderer for window
			gRenderer = SDL_CreateRenderer( gWindow, -1, SDL_RENDERER_ACCELERATED );
			if( gRenderer == NULL )
			{
				printf( "Renderer could not be created! SDL Error: %s\n", SDL_GetError() );
				success = false;
			}
			else
			{
				//Initialize renderer color
				SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );

				//Initialize PNG loading
				int imgFlags = IMG_INIT_PNG;
				if( !( IMG_Init( imgFlags ) & imgFlags ) )
				{
					printf( "SDL_image could not initialize! SDL_image Error: %s\n", IMG_GetError() );
					success = false;
				}
			}
		}
	}

	return success;
}

bool loadMedia()
{
	//Loading success flag
	bool success = true;

	//load tank body
	bg = loadTexture("bg.png");
    if(bg==NULL)
    {
        printf("Unable to run due to error: %s\n",SDL_GetError());
        success =false;
    }

	mario = loadTexture("mario.png");
    if(mario==NULL)
    {
        printf("Unable to run due to error: %s\n",SDL_GetError());
        success =false;
    }

	return success;
}

void close()
{
	//Free loaded images
	SDL_DestroyTexture( bg );
	bg = NULL;
	SDL_DestroyTexture(mario);
	mario=NULL;
	
	//Destroy window
	SDL_DestroyRenderer( gRenderer );
	SDL_DestroyWindow( gWindow );
	gWindow = NULL;
	gRenderer = NULL;

	//Quit SDL subsystems
	IMG_Quit();
	SDL_Quit();
}

SDL_Texture* loadTexture( std::string path )
{
	//The final texture
	SDL_Texture* newTexture = NULL;

	//Load image at specified path
	SDL_Surface* loadedSurface = IMG_Load( path.c_str() );
	if( loadedSurface == NULL )
	{
		printf( "Unable to load image %s! SDL_image Error: %s\n", path.c_str(), IMG_GetError() );
	}
	else
	{
		//Create texture from surface pixels
        newTexture = SDL_CreateTextureFromSurface( gRenderer, loadedSurface );
		if( newTexture == NULL )
		{
			printf( "Unable to create texture from %s! SDL Error: %s\n", path.c_str(), SDL_GetError() );
		}

		//Get rid of old loaded surface
		SDL_FreeSurface( loadedSurface );
	}

	return newTexture;
}

int main( int argc, char* args[] )
{
    SDL_RenderClear( gRenderer );




    srcRect.x=0;
	srcRect.y=0;
    srcRect.w=800;
    srcRect.h=600;
    mover.x=0;
    mover.y=0;
    mover.w=800;
    mover.h=600;
	marioSrc.x=200;
	marioSrc.y=50;
	marioSrc.w=30;
	marioSrc.h=30;
	marioMover.x=30;
	marioMover.y=430;
	marioMover.w=100;
	marioMover.h=100;
	//Start up SDL and create window
	if( !init() )
	{
		printf( "Failed to initialize!\n" );
	}
	else
	{
		//Load media
		if( !loadMedia() )
		{
			printf( "Failed to load media!\n" );
		}
		else
		{
			//Main loop flag
			bool quit = false;

			//Event handler
			SDL_Event e;

			//While application is running
			while( !quit )
			{
				//Handle events on queue
				while( SDL_PollEvent( &e ) != 0 )
				{
					//User requests quit
					if( e.type == SDL_QUIT )
					{
						quit = true;
					}

	
				}

				//Clear screen
				// SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );
				if (X<650)
				UpdateMario();
				else{
					marioMover.w=150;
					marioMover.h=150;
					marioMover.x=610;
					marioMover.y=380;
					SDL_RenderClear( gRenderer );
					SDL_RenderCopy( gRenderer, bg, &srcRect, &mover );
					SDL_RenderCopy( gRenderer, mario, &marioSrc, &marioMover );
					SDL_RenderPresent( gRenderer );
				}
				// quit=true;


				//Update screen
				
			}
			
		}
	}

	//Free resources and close SDL
	close();

	return 0;
}
 //In today's lab you will make a new tank say, "NewTank" that inherits from
 //Unit class and Display it on screen
 //You will then create a linked list that will load up 10 tanks and newtanks
 //and show them on screen. When the program finishes, everything must deallocate.
