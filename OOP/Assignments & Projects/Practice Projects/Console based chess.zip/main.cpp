#include "piece.h"
#include "board.h"
using namespace std;

int main() {
    Board* board = new Board();
    do{
        board->print_board();
        board->moveInterface();
    }while(true);
    delete board;
}
