#pragma once

#include <iostream>
// We define a print() function that takes in arbitrary arguments and print with a space
// Notice the inline? without inline, each cpp file where base.h is include will have a copy of these functions and will create definition conflicts
// Base case: no arguments
inline void println() {
    std::cout << std::endl;
}

// Recursive template: one or more arguments
template <typename T, typename... Args>
inline void println(T first, Args... rest) {
    std::cout << first << " ";
    println(rest...);
}

// Following for print, without new line
inline void print() {} // a base case that does nothing lol

// Recursive template: one or more arguments
template <typename T, typename... Args>
inline void print(T first, Args... rest) {
    std::cout << first << " ";
    print(rest...);
}

//template <class... Args>
// void print(const Args&... args) {
//     ((std::cout << args << ' '), ...);
//     std::cout << '\n';
// }
// The fold expands to ((cout << a0 << ' '), (cout << a1 << ' '), ...).