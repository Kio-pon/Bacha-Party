// board.h
#pragma once

#include "piece.h"

class Board {
public:
    Board();
    ~Board();
    void print_board() const;
    Piece* at(int p) const {return board[p];}
    const bool turn() const {return WhiteTurn? 0 : 1;}
    void ChangeTurn() {WhiteTurn = !WhiteTurn;}
    void moveInterface();

private:
    Piece* board[64];
    bool WhiteTurn = true;
    // inline static bool WhiteTurn = true;
    // this is a fancy way of initializing static members within class.
    // without inline we will need the code-line "bool Board::WhiteTurn = true;" to be in board.cpp
    // the keyword "inline" just does this for us
};
