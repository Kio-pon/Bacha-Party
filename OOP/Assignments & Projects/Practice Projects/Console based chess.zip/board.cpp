//#include <iostream> included in base.h
#include "board.h"
#include "base.h"
using namespace std;

Board::Board(){
    WhiteTurn = true; // White starts first
    int p = 0;
    for(Piece* x : this->board){
        x = nullptr;
    }

    // white pieces
    board[0] = new Rook(0, 0);
    board[1] = new Knight(1, 0);
    board[2] = new Bishop(2, 0);
    board[3] = new Queen(3, 0);
    board[4] = new King(4, 0);
    board[5] = new Bishop(5, 0);
    board[6] = new Knight(6, 0);
    board[7] = new Rook(7, 0);
    for(int i = 8; i < 16; i++) board[i] = new Pawn(i, 0);

    // black pieces
    board[0+7*8] = new Rook(0, 1);
    board[1+7*8] = new Knight(1, 1);
    board[2+7*8] = new Bishop(2, 1);
    board[3+7*8] = new Queen(3, 1);
    board[4+7*8] = new King(4, 1);
    board[5+7*8] = new Bishop(5, 1);
    board[6+7*8] = new Knight(6, 1);
    board[7+7*8] = new Rook(7, 1);
    for(int i = 6*8; i < 7*8; i++) board[i] = new Pawn(i, 1);
}

Board::~Board() {
    for (Piece* x : board) delete x;
    for (Piece* x : board) x = nullptr; // NO DANGLING POINTER
}

void Board::print_board() const{
    for(int r = 7; r >= 0; r--){
        for(int c = 0; c < 8; c++){
            const Piece* p = board[8*r + c];
            if(p) print(p->symbol(), "\t");
            else print(".\t");
        }
        cout << endl << endl;
    }
}

void Board::moveInterface(){
    // move interface
    int from; print("From: "); cin >> from;
    int to; print("To: "); cin >> to;
    Piece* current = this->at(from); //notice the object slicing problem if not designed properly?
    if(current){
        if(current->legal_move(to, *this)) {
            current->move(to);
            board[to] = current;
            board[from] = nullptr;
            ChangeTurn();
        }
    }
    else println("select non empty box!");
}