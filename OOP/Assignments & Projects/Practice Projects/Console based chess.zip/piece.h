// piece.h
#pragma once

// we are using string view for the following reasons:
// 1. no allocation, no copies (so no overhead when passing to fucntion or being created)
// 2. The above properties make it so that it behaves like string& 
// 3. Easier to handle memory compared to char*
// CAUTION: only included in c++17+
#include <string_view>

// forward declaration to avoid circular includes
class Board;

// Abstract Class of a piece
class Piece {
public:
    // constructor
    Piece(int pos, unsigned int player) : pos(pos), player(player) {}
    
    // virtual destructor 
    // ""= 0" means each class will implement it's own destructor, but then we will still have to show its implementation
    // we could have used "= default" to ask compiler to make a default constructor assuming no special cleanup is required
    virtual ~Piece() = default;

    // pure virtual functions
    virtual bool legal_move(int final_pos, const Board& board) const = 0;
    virtual const std::string_view symbol() const = 0;

    // simple member functions
    void move(int final_pos) {this->pos = final_pos;}
    int get_player() const {return player;}
    int get_pos() const {return pos;}

protected:
    int pos;
    unsigned int player; // by convention player = 0 is white, player = 1 is black
};

// A Derived class of Pawn from the abstract class of piece
class Pawn : public Piece {
public:
    // Constructor
    // the following synatax just brings the constructor of base class into derived class' scope
    using Piece::Piece;
    bool legal_move(int final_pos, const Board& board) const override;
    const std::string_view symbol() const override {return player ? u8"\u265F" : u8"\u2659";}
};

// A Derived class of Pawn from the abstract class of piece
class Knight : public Piece {
public:
    using Piece::Piece;
    bool legal_move(int final_pos, const Board& board) const override;
    const std::string_view symbol() const override {return player ? u8"\u2658" : u8"\u265E";}
};

// --- Bishop ---
class Bishop : public Piece {
public:
    using Piece::Piece;
    bool legal_move(int final_pos, const Board& board) const override;
    const std::string_view symbol() const override {return player ? u8"\u2657" : u8"\u265D";}
};

// --- Rook ---
class Rook : public Piece {
public:
    using Piece::Piece;
    bool legal_move(int final_pos, const Board& board) const override;
    const std::string_view symbol() const override {return player ? u8"\u2656" : u8"\u265C";}
};

// --- King ---
class King : public Piece {
public:
    using Piece::Piece;
    bool legal_move(int final_pos, const Board& board) const override;
    const std::string_view symbol() const override {return player ? u8"\u2654" : u8"\u265A";}
};

class Queen : public Piece {
public:
    Queen(int pos, unsigned int player) : Piece(pos, player) {
        this->rook_part = new Rook(this->pos, this->player);
        this->bishop_part = new Bishop(this->pos, this->player);
    }
    ~Queen(){
        delete this->rook_part;
        delete this->bishop_part;
    }
    bool legal_move(int final_pos, const Board& board) const override;
    const std::string_view symbol() const override {return player ? u8"\u2654" : u8"\u265A";}
private:
    Rook* rook_part;
    Bishop* bishop_part;
};
