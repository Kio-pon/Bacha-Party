//#include "piece.h" (piece.h is already included in board.h)
#include "board.h"
#include "base.h"
//#include <iostream> (iostream already included in base.h)
//#include <cstdlib> // for absolute function
using namespace std;

bool Pawn::legal_move(int final_pos, const Board& Board) const {
    if(final_pos > 63) {println("Going out of the board!"); return false;} // there are total 64 squares
    if(Board.turn() != this->get_player()) {println("Choose your own pieces!"); return false;} // check whether players are using their own pieces
    if(abs(final_pos - this->pos) == 8 && !Board.at(final_pos)) return true; // moving forward conditions
    
    // sideways capture conditions
    if(abs(final_pos - this->pos) == 7 || abs(final_pos - this->pos) == 9) {
        if(Board.at(final_pos)->get_player() != this->get_player()) return true;
    }

    // double move from starting rank rule check
    if(abs(final_pos - this->pos) == 16) {
        if((7 < this->pos && this->pos < 16) || (47 < this->pos && this->pos < 56)) {
            if(legal_move(final_pos - int((final_pos - this->pos)/2), Board) && !Board.at(final_pos)) return true; // notice the recursion?
            // logic explanation. Recursion to check if the space in between in not occupied
            // logic explanation. final_pos - int((final_pos - this->pos)/2) can be changed with final_pos - 8 for white
            //                      but it hast to be final_pos + 8 for black. The second part calcuates if its +8 or -8
        }
    }
    println("Illegal pawn move!");
    return false;
}

bool Rook::legal_move(int final_pos, const Board& Board) const {
    return true;
}

bool Bishop::legal_move(int final_pos, const Board& Board) const {
    return true;
}

bool Knight::legal_move(int final_pos, const Board& Board) const {
    return true;
}

bool King::legal_move(int final_pos, const Board& Board) const {
    return true;
}

bool Queen::legal_move(int final_pos, const Board& Board) const {
    return true;
}